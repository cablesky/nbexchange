if __name__ == "__main__":
    from .app import main

    main()
