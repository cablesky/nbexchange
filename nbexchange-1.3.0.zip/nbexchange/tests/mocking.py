""" mock some parts of the exchange, pretend it's a server """
