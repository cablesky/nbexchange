from nbexchange import dbutil


def test_dbutil():
    dbutil.main()
