from traitlets.config import get_config

c = get_config()
