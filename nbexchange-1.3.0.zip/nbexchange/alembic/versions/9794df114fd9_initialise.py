"""initialise

Revision ID: 9794df114fd9
Revises:
Create Date: 2018-10-29 16:06:19.741739

"""

# revision identifiers, used by Alembic.
revision = "9794df114fd9"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
